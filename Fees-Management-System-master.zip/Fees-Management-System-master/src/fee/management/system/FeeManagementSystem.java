package fee.management.system;
public class FeeManagementSystem {
    public static void main(String[] args) {
       signup sn = new signup();
       sn.setVisible(true);
    }   
}