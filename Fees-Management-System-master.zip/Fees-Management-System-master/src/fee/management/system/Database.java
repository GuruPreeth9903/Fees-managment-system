
package fee.management.system;

class Database {
    
}
