# Fees-Management-System
This Project is about fees management system using NetBeans using MYSql
There are 7modules:
1.signup page
2.login page
3.home page
  3.1 add fee
  3.2 edit courses
  3.3 search record

To run this Project need to install
  1.mysql-connector-j-8.0.32.jar(or better version) : for connecting mysql with java(NetBeans).
  2.jCalander-1.4.jar : for selecting date inside the projet.
  3.java db- AbsoluteLayout.jar: which will be already installed.
  
